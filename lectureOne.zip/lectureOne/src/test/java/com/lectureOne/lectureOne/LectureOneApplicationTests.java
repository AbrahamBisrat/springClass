package com.lectureOne.lectureOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LectureOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
